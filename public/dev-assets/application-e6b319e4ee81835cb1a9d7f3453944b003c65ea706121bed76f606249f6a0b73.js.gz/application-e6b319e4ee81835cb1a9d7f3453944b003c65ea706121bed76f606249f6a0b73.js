(function() {
  console.log('Hello world from coffeescript');

}).call(this);
